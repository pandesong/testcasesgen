from setuptools import setup, find_packages

setup(
    name="ObjectToString",
    version="0.2.1",
    description="ObjectToString",
    author="pds",
    packages=find_packages(),
    install_requires=[
       
    ],
)
